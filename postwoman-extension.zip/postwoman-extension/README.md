# Postwoman Browser Extension

## Postwoman Browser Extension使用说明

1. 安装插件

   将同级目录下的dist文件夹直接拖拽至Chrome浏览器安装插件

2. 开启插件

   根据需要可以将此扩展程序应用于特定网站或者所有网站上,配置如下图所示。

   **PS**：以下图片如果加载不了，请直接打开同级目录下的postwoman-extension.jpg进行查看

   ![avatar](postwoman-extension.jpg)